terraform {
  required_providers {
    ibm = {
      source  = "IBM-Cloud/ibm"
      version = "= 1.65.0"
    }
  }
}

provider "ibm" {
  region = "us-east"
  ibmcloud_api_key = var.ibm_api_key
}

variable "vpc_config"{
  type = bool
  default = false
}
variable "subnet_cidr" {
  description = "CIDR block for the subnet (e.g., 10.240.0.0/24)"
  type        = string
  default     = "10.240.0.0/24"
  
  validation {
    condition     = can(cidrhost(var.subnet_cidr, 0))
    error_message = "The subnet_cidr must be a valid CIDR block."
  }
}

variable "vpc_name" {
  description = "Name for the VPC"
  type        = string
  default     = "iotmax-vpc"
}

variable "subnet_name" {
  description = "Name for the subnet"
  type        = string
  default     = "iotmax-subnet"
}

variable "zone" {
  description = "Zone where the subnet will be created"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Name of the Code Engine project"
  type        = string
}

data "ibm_resource_group" "default" {
  name = "Default"
}

resource "ibm_is_vpc" "vpc" {
  count          = var.vpc_config ? 1 : 0
  name           = var.vpc_name
  resource_group = data.ibm_resource_group.default.id
  tags           = ["terraform", "vpc", "code-engine", "iotmax"]
}

resource "ibm_is_subnet" "subnet" {
  name                     = var.subnet_name
  count                    = var.vpc_config ? 1 : 0
  vpc                      = ibm_is_vpc.vpc[0].id
  zone                     = var.zone
  ipv4_cidr_block         = var.subnet_cidr
  resource_group          = data.ibm_resource_group.default.id
  
  tags = ["terraform", "subnet", "code-engine", "iotmax"]
}

resource "ibm_is_public_gateway" "gateway" {
  count          = var.vpc_config ? 1 : 0
  name           = "${var.vpc_name}-gateway"
  vpc            = ibm_is_vpc.vpc[0].id
  zone           = var.zone
  resource_group = data.ibm_resource_group.default.id
  
  tags = ["terraform", "gateway", "code-engine", "iotmax"]
}

resource "ibm_is_subnet_public_gateway_attachment" "subnet_gateway" {
  count          = var.vpc_config ? 1 : 0
  subnet         = ibm_is_subnet.subnet[0].id
  public_gateway = ibm_is_public_gateway.gateway[0].id
}

# Security group for Code Engine applications
resource "ibm_is_security_group" "code_engine_sg" {
  count          = var.vpc_config ? 1 : 0
  name           = "${var.vpc_name}-code-engine-sg"
  vpc            = ibm_is_vpc.vpc[0].id
  resource_group = data.ibm_resource_group.default.id
  
  tags = ["terraform", "security-group", "code-engine", "iotmax"]
}

# Allow inbound HTTPS traffic
resource "ibm_is_security_group_rule" "code_engine_https_inbound" {
  count          = var.vpc_config ? 1 : 0
  group     = ibm_is_security_group.code_engine_sg[0].id
  direction = "inbound"
  remote    = "0.0.0.0/0"
  tcp {
    port_min = 443
    port_max = 443
  }
}

# Allow inbound HTTP traffic
resource "ibm_is_security_group_rule" "code_engine_http_inbound" {
  count          = var.vpc_config ? 1 : 0
  group     = ibm_is_security_group.code_engine_sg[0].id
  direction = "inbound"
  remote    = "0.0.0.0/0"
  tcp {
    port_min = 80
    port_max = 80
  }
}

# Allow inbound traffic on port 8000 (backend)
resource "ibm_is_security_group_rule" "code_engine_backend_inbound" {
  count          = var.vpc_config ? 1 : 0
  group     = ibm_is_security_group.code_engine_sg[0].id
  direction = "inbound"
  remote    = "0.0.0.0/0"
  tcp {
    port_min = 8000
    port_max = 8000
  }
}

# Allow inbound traffic on port 3000 (frontend)
resource "ibm_is_security_group_rule" "code_engine_frontend_inbound" {
  count          = var.vpc_config ? 1 : 0
  group     = ibm_is_security_group.code_engine_sg[0].id
  direction = "inbound"
  remote    = "0.0.0.0/0"
  tcp {
    port_min = 3000
    port_max = 3000
  }
}

resource "ibm_code_engine_config_map" "vpc_config" {
  count      = var.vpc_config ? 1 : 0
  project_id = ibm_code_engine_project.project.project_id
  name       = "${var.project_name}-vpc-config"

  data = {
    vpc_id      = ibm_is_vpc.vpc[0].id
    subnet_id   = ibm_is_subnet.subnet[0].id
    subnet_cidr = var.subnet_cidr
    zone        = var.zone
  }
}

# Allow outbound traffic
resource "ibm_is_security_group_rule" "code_engine_outbound" {
  count          = var.vpc_config ? 1 : 0
  group     = ibm_is_security_group.code_engine_sg[0].id
  direction = "outbound"
  remote    = "0.0.0.0/0"
}

resource "ibm_code_engine_project" "project" {
  name = var.project_name
  resource_group_id = data.ibm_resource_group.default.id
}

variable "backend_image" {
  default = "icr.io/iotmaxapi/iotmaxapi:latest"
}



variable "frontend_image" {
  default = "icr.io/iotmax-frontend/iotmax-frontend:latest"
}

variable "ibm_api_key" {
  description = "IBM Cloud API Key"
  type        = string
  sensitive   = true
}

variable "registry_secret_name" {
  default = "icr-secret"
}

variable "backend_env_vars" {
  description = "Custom environment variables for backend"
  type        = map(string)
  default     = {}
}



resource "ibm_code_engine_secret" "registry_secret" {
  project_id = ibm_code_engine_project.project.project_id
  name       = var.registry_secret_name
  format     = "registry"
  data = {
    "username" = "iamapikey"
    "password" = var.ibm_api_key
    "server"   = "icr.io"
  }
}

resource "ibm_code_engine_app" "backend" {
  name            = "iotmax-backend"
  project_id      = ibm_code_engine_project.project.project_id
  image_reference = var.backend_image
  image_port      = 8000
  image_secret    = ibm_code_engine_secret.registry_secret.name


  timeouts {
    create = "10m"
  }
  dynamic "run_env_variables" {
    for_each = var.backend_env_vars
    content {
      type  = "literal"
      name  = run_env_variables.key
      value = run_env_variables.value
    }
  }
  scale_cpu_limit    = "1"
  scale_memory_limit = "2G"
  scale_min_instances = 0
  scale_max_instances = 1
}

resource "ibm_code_engine_app" "frontend" {
  name            = "iotmax-frontend"
  project_id      = ibm_code_engine_project.project.project_id
  image_reference = var.frontend_image
  image_secret    = ibm_code_engine_secret.registry_secret.name
  image_port      = 3000
  depends_on = [ ibm_code_engine_app.backend ]


  run_env_variables {
    type  = "literal"
    name  = "REACT_APP_BACKEND_URL"
    value = "${ibm_code_engine_app.backend.endpoint}/api"
  }
  timeouts {
    create = "10m"
  }
}

output "backend_url" {
  value =  ibm_code_engine_app.backend.endpoint
}

output "frontend_url" {
  value =  ibm_code_engine_app.frontend.endpoint
}

output "vpc_id" {
  value       = var.vpc_config ? ibm_is_vpc.vpc[0].id : null
  description = "ID of the created VPC, if any"
}
